<?php include("head.php") ?>


<!DOCTYPE html>
<html>
<head>
    <style>
        body {
            background-image: url('https://www.esri.ca/content/distributor-sites/esri-ca/en-ca/home/geospatial-thinking/stories/agriculture/_jcr_content/par/grid_container_copy__742547375/gc-par/columnsystem/wpar/image.img.jpg/1630824034880.jpg');
            background-size: cover;
            background-position: cover;
            background-repeat: no-repeat;
            margin: 0;
            padding: 0;
        }
    </style>
</head>
<body>
</body>
</html>

