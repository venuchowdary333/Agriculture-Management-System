<?php include("head.php") ?>


<!DOCTYPE html>
<html>
<head>
    <style>
        body {
            background-image: url('https://img.jagranjosh.com/imported/images/E/GK/modern-agriculture-impact-on-environment-gk.jpg');
            background-size: cover;
            background-position: cover;
            background-repeat: no-repeat;
            margin: 0;
            padding: 0;
        }
    </style>
</head>
<body>
</body>
</html>