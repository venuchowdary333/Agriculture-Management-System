<?php include("head.php") ?>

<!DOCTYPE html>
<html>
<head>
    <style>
        body {
            background-image: url('https://www.iisd.org/sites/default/files/styles/banner_mobile/public/2020-06/RS2085_food-agriculture-topic.jpg?h=10d202d3&itok=keVtNY82');
            background-size: cover;
            background-position: cover;
            background-repeat: no-repeat;
            margin: 0;
            padding: 0;
        }
    </style>
</head>
<body>
</body>
</html>