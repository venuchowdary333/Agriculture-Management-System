<head>
    <title>Agriculture</title>
    <link rel="stylesheet" type="text/css" href="css/typo.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/nav.css">
    <link rel="stylesheet" type="text/css" href="css/units.css">
    <link rel="stylesheet" type="text/css" href="css/utilities.css">
</head>