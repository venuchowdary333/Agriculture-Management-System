
<?php include("head.php") ?>
<?php include("dbConn.php") ?>
<?php
$product_availability_id = $_GET['product_availability_id'];
?>


<!-- <div class="row">
    <div class="w-30"></div>
    <div class="w-20">
    <div class="card mt-100  P-15 bg-secondary">
        <div class="text-center text-secondary mt-20  h5">Add To Cart</div>
        <form action="add_to_cart_action.php" method="POST">
            <input type="hidden" name="product_availability_id" value="<?php echo $product_availability_id ?>" >
            <div class="form-group  mt-25">
                <input type="number" name="quantity" id="quantity" class="form-control p-5 bg-secondary" placeholder="" required>
                <label for="quantity" class="form-label p-5">Enter Quantity</label>
                <div class="middle"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-geo-alt-fill" viewBox="0 0 16 16"><path d="M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10m0-7a3 3 0 1 1 0-6 3 3 0 0 1 0 6"/></svg></div>
            </div>
            <div class="form-group  mt-25">
                <input type="date" name="date" id="date" class="form-control p-5 bg-secondary" placeholder="" required>
                <label for="date" class="form-label p-5">Enter Quantity</label>
                <div class="middle"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-geo-alt-fill" viewBox="0 0 16 16"><path d="M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10m0-7a3 3 0 1 1 0-6 3 3 0 0 1 0 6"/></svg></div> -->
            <!-- </div>
            <input type="submit" value="Add To Cart" class="btn bg-primary text-white p-10 mt-25">
        </form>
    </div>
    <div class="w-30"></div>
</div> -->



  