<?php include("head.php") ?>
<?php include("dbConn.php") ?>
<?php 
$category_name = $_POST['category_name'];

$sql = "select * from categories where category_name='".$category_name."' ";
$locations = $conn->query($sql);
if($locations->num_rows>0){
   $url =  "msg.php?msg=Already Exist&color=text-danger";
   header("Location:".$url);
}else{
    $sql = "insert into categories(category_name)
    values('".$category_name."')"; 
    if($conn->query($sql)==TRUE){
    $url =  "add_category.php";
    header("Location:".$url);
    }else{
        $url = "msg.php?msg=Something Went Wrong&color=text-danger";
        header("Location:".$url);
    }
}
?>