drop database Agriculture;
create database Agriculture;
use Agriculture;

create table locations(
location_id int auto_increment primary key,
location_name  varchar(255) not null,
zipcode  varchar(255) not null
);

create table sellers(
seller_id int auto_increment primary key,
first_name varchar(255) not null,
last_name varchar(255) not null,
phone varchar(255) not null ,
email varchar(255) not null ,
password varchar(255) not null,
state varchar(255) not null,
city varchar(255) not null,
zipcode varchar(255) not null,
address varchar(255) not null,
status varchar(255) not null default 'UnAuthorized',
location_id int ,
foreign key (location_id) references locations(location_id)
);


create table farmers(
farmer_id int auto_increment primary key,
first_name varchar(255) not null,
last_name varchar(255) not null,
phone varchar(255) not null ,
email varchar(255) not null ,
password varchar(255) not null,
state varchar(255) not null,
city varchar(255) not null,
zipcode varchar(255) not null,
address varchar(255) not null
);


create table deliveryboys(
deliveryboy_id int auto_increment primary key,
name varchar(255) not null,
phone varchar(255) not null ,
email varchar(255) not null ,
password varchar(255) not null,
state varchar(255) not null,
city varchar(255) not null,
zipcode varchar(255),
address varchar(255) not null,
location_id int ,
foreign key (location_id) references locations(location_id)
);


create table categories(
category_id int auto_increment primary key,
category_name  varchar(255) not null
);


create table products(
product_id int auto_increment primary key,
product_name varchar(345) not null,
image varchar(345) not null,
price varchar(345) not null,
description varchar(345) not null,
category_id int ,
foreign key (category_id) references categories(category_id)
);

create table product_availability(
product_availability_id int auto_increment primary key,
quantity varchar(255),
price varchar(255),
product_id int,
foreign key (product_id) references products(product_id),
seller_id int,
foreign key (seller_id) references sellers(seller_id)
);



create table orders(
order_id  int auto_increment primary key,
date varchar(345) not null,
status varchar(345),
seller_id int,
foreign key (seller_id) references sellers(seller_id),
farmer_id int,
foreign key (farmer_id) references farmers(farmer_id),
order_type varchar(255),
deliveryboy_id int,
foreign key (deliveryboy_id) references deliveryboys(deliveryboy_id),
total_price varchar(255)
);



create table order_items(
order_item_id  int auto_increment primary key,
quantity varchar(255),
order_id int,
foreign key (order_id) references orders(order_id),
product_availability_id int,
request_quantity int,
foreign key (product_availability_id) references product_availability(product_availability_id)

);


CREATE TABLE backorders (
    backorder_id INT AUTO_INCREMENT PRIMARY KEY,
    farmer_id INT,
    product_availability_id INT,
    order_id INT,
    quantity INT NOT NULL,
    status VARCHAR(255) DEFAULT 'Pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (farmer_id) REFERENCES farmers(farmer_id),
    FOREIGN KEY (product_availability_id) REFERENCES product_availability(product_availability_id),
    FOREIGN KEY (order_id) REFERENCES orders(order_id)
);



create table payments(
payment_id  int auto_increment primary key,
payment_type varchar(255) not null,
card_number varchar(255) not null,
holder_name varchar(255) not null,
cvv varchar(255) not null,
expiry_date varchar(255) not null,
amount varchar(255) not null,
status varchar(255) not null,
order_id int,
foreign key (order_id) references orders(order_id)
);


create table reviews(
review_id  int auto_increment primary key,
rating varchar(255),
review varchar(345) not null,
farmer_id int,
foreign key (farmer_id) references farmers(farmer_id),
order_id int,
foreign key (order_id) references orders(order_id)
);

create table product_notifications(
product_notificationId int auto_increment primary key,
status varchar(255) not null,
product_availability_id int,
farmer_id int,
foreign key (product_availability_id) references product_availability(product_availability_id),
foreign key (farmer_id) references farmers(farmer_id)
);